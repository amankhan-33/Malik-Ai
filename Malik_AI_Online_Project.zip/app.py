import os
from flask import Flask, request, jsonify, send_from_directory
from google import genai

app = Flask(__name__, static_folder=".", static_url_path="")
api_key = os.environ.get("GEMINI_API_KEY", "").strip()
client = genai.Client(api_key=api_key) if api_key else None
SYSTEM = "You are Malik AI, Aman’s personal assistant. Reply clearly and helpfully, preferably in simple Urdu or Roman Urdu when the user uses Urdu or Roman Urdu."

@app.get("/")
def home():
    return send_from_directory(".", "index.html")

@app.post("/chat")
def chat():
    data = request.get_json(silent=True) or {}
    question = str(data.get("text", "")).strip()
    if not question:
        return jsonify({"reply": "براہِ کرم اپنا سوال لکھیں۔"}), 400
    if client is None:
        return jsonify({"reply": "AI key ابھی سیٹ نہیں ہوئی۔ ہوسٹنگ میں GEMINI_API_KEY سیٹ کریں۔"}), 503
    try:
        result = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=question,
            config={"system_instruction": SYSTEM},
        )
        return jsonify({"reply": result.text or "مجھے جواب نہیں ملا۔"})
    except Exception:
        app.logger.exception("AI request failed")
        return jsonify({"reply": "AI سے رابطے میں مسئلہ آیا۔ API key اور server logs چیک کریں۔"}), 502

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")))
